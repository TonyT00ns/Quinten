<?php
// database logingegevens
$db_hostname = 'localhost';
$db_username = '82128';
$db_password = 'vCNKma';
$db_database = 'db82128';

// maak de database-verbinding
$mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);

