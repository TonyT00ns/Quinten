<?php

// Start de sessions
session_start();
// Verwijder alle sessions
session_destroy();
// Stuur de gebruiker naar de inlogpagina
header("location:inlog.php");

?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title> OPDRACHT 6 - Uitlog </title>
	</head>

	<body>
	
	</body>
</html>